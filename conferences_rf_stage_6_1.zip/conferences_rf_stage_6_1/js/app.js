// Демонстрационная логика на JavaScript. Данные хранятся в браузере,
// это НЕ подключение к PostgreSQL и не серверная база данных.
const $ = (s, root=document) => root.querySelector(s);
const read = (key, fallback=[]) => { try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; } };
const write = (key, value) => localStorage.setItem(key, JSON.stringify(value));
const msg = (text, type='success') => { const box=$('#messages'); if(box) box.innerHTML=`<div class="alert alert--${type}">${text}</div>`; };
const esc = s => String(s ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statuses=['Новая','Мероприятие назначено','Завершено'];

const reg=$('#register-form');
if(reg) reg.addEventListener('submit', e=>{ e.preventDefault(); const d=Object.fromEntries(new FormData(reg)); let errors={};
 if(!/^[A-Za-z0-9]{6,}$/.test(d.login)) errors.login='Логин: латинские буквы и цифры, не менее 6 символов.';
 if((d.password||'').length<8) errors.password='Пароль должен содержать не менее 8 символов.';
 if(!/^[А-Яа-яЁё ]+$/.test(d.full_name)) errors.full_name='Укажите ФИО кириллицей.';
 if(!/^8\([0-9]{3}\)[0-9]{3}-[0-9]{2}-[0-9]{2}$/.test(d.phone)) errors.phone='Формат: 8(900)123-45-67.';
 if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) errors.email='Проверьте адрес электронной почты.';
 reg.querySelectorAll('[data-error]').forEach(el=>el.textContent=errors[el.dataset.error]||'');
 if(Object.keys(errors).length) return;
 const users=read('conf_users'); if(users.some(u=>u.login===d.login)){msg('Такой логин уже зарегистрирован.','danger');return;}
 users.push(d); write('conf_users',users); msg('Регистрация выполнена в демонстрационном режиме. Теперь можно войти.'); reg.reset();
 });
const login=$('#login-form');
if(login) login.addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(login));const u=read('conf_users').find(x=>x.login===d.login&&x.password===d.password);if(!u){msg('Пользователь не найден. Сначала зарегистрируйтесь на этом устройстве.','danger');return;}localStorage.setItem('conf_current_user',u.login);location.href='cabinet.html';});
const booking=$('#booking-form');
if(booking) booking.addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(booking));const list=read('conf_bookings');list.push({...d,id:Date.now(),status:'Новая',user:localStorage.getItem('conf_current_user')||'Гость'});write('conf_bookings',list);msg('Заявка добавлена в демонстрационный список.');booking.reset();});
function card(b, admin=false){return `<article class="booking-card"><div class="booking-card__top"><div><span class="eyebrow">ЗАЯВКА №${esc(String(b.id).slice(-6))}</span><h2>${esc(b.room_name)}</h2></div><span class="status status--${b.status==='Завершено'?'done':b.status==='Мероприятие назначено'?'active':'new'}">${esc(b.status)}</span></div><div class="booking-meta"><div><small>Дата начала</small><b>${esc(b.start_date)}</b></div><div><small>Способ оплаты</small><b>${esc(b.payment_method)}</b></div>${admin?`<div><small>Пользователь</small><b>${esc(b.user)}</b></div>`:''}</div>${admin?`<div class="admin-actions"><label>Изменить статус <select class="form-control" data-status="${b.id}">${statuses.map(s=>`<option ${s===b.status?'selected':''}>${s}</option>`).join('')}</select></label><button class="text-link text-link--danger" data-delete="${b.id}">Удалить заявку</button></div>`:''}</article>`;}
const list=$('#booking-list'); if(list){const current=localStorage.getItem('conf_current_user')||'Гость';const rows=read('conf_bookings').filter(b=>b.user===current);list.innerHTML=rows.length?rows.map(b=>card(b)).join(''):`<div class="empty-state"><div class="empty-state__icon">✦</div><h2>Пока нет заявок</h2><p>Создайте первую заявку, чтобы забронировать помещение для вашего события.</p><a class="button" href="booking_new.html">Создать заявку</a></div>`;}
const adminList=$('#admin-list');
function renderAdmin(){if(!adminList)return;const filter=$('#status-filter')?.value||'';const rows=read('conf_bookings').filter(b=>!filter||b.status===filter);adminList.innerHTML=rows.length?rows.map(b=>card(b,true)).join(''):`<div class="empty-state"><h2>Заявок пока нет</h2><p>Создайте заявку на сайте, чтобы она появилась здесь.</p></div>`;}
if(adminList){renderAdmin();$('#status-filter').addEventListener('change',renderAdmin);adminList.addEventListener('change',e=>{if(e.target.matches('[data-status]')){const rows=read('conf_bookings');const b=rows.find(x=>String(x.id)===e.target.dataset.status);if(b){b.status=e.target.value;write('conf_bookings',rows);renderAdmin();}}});adminList.addEventListener('click',e=>{const id=e.target.dataset.delete;if(id){write('conf_bookings',read('conf_bookings').filter(b=>String(b.id)!==id));renderAdmin();}});}
// Слайдер главной страницы
const slider=$('[data-slider]'); if(slider){const slides=[...slider.querySelectorAll('.slide')],dots=[...slider.querySelectorAll('.slider__dot')];let active=0;function show(i){active=i;slides.forEach((s,n)=>s.classList.toggle('is-active',n===i));dots.forEach((d,n)=>d.classList.toggle('is-active',n===i));}dots.forEach((d,i)=>d.addEventListener('click',()=>show(i)));setInterval(()=>show((active+1)%slides.length),4500);}
